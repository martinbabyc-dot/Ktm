import * as React from "react";
import { cn } from "@/lib/utils";

function Input({ className, ...props }: React.ComponentProps<"input">) {
  return (
    <input
      className={cn(
        "h-11 w-full rounded-[10px] bg-surface-2 px-3 text-sm text-fg shadow-[0_0_0_1px_rgba(232,236,239,0.08)] outline-none placeholder:text-faint focus-visible:shadow-[0_0_0_1px_var(--color-accent)]",
        className,
      )}
      {...props}
    />
  );
}

function Textarea({ className, ...props }: React.ComponentProps<"textarea">) {
  return (
    <textarea
      className={cn(
        "min-h-28 w-full resize-y rounded-2xl bg-surface-2 px-3 py-3 text-sm leading-normal text-fg shadow-[0_0_0_1px_rgba(232,236,239,0.08)] outline-none placeholder:text-faint focus-visible:shadow-[0_0_0_1px_var(--color-accent)]",
        className,
      )}
      {...props}
    />
  );
}

export { Input, Textarea };
