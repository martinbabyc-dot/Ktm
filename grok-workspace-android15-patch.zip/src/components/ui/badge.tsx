import { cva, type VariantProps } from "class-variance-authority";
import { cn } from "@/lib/utils";

const badgeVariants = cva(
  "inline-flex items-center rounded-full px-2.5 py-1 text-[11px] font-medium tracking-wide uppercase",
  {
    variants: {
      tone: {
        mute: "bg-surface-2 text-muted",
        accent: "bg-accent/15 text-accent",
        red: "bg-ice-red/15 text-ice-red",
        green: "bg-ice-green/15 text-ice-green",
        gold: "bg-ice-gold/15 text-ice-gold",
      },
    },
    defaultVariants: { tone: "mute" },
  },
);

function Badge({
  className,
  tone,
  ...props
}: React.ComponentProps<"span"> & VariantProps<typeof badgeVariants>) {
  return <span className={cn(badgeVariants({ tone, className }))} {...props} />;
}

export { Badge, badgeVariants };
