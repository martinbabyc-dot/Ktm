import { cn } from "@/lib/utils";

export function PlaneMark({ className }: { className?: string }) {
  return (
    <svg
      viewBox="0 0 32 32"
      aria-hidden="true"
      className={cn("text-accent", className)}
      fill="none"
      stroke="currentColor"
      strokeWidth="1.5"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M3 21h26" />
      <path d="M7 21c4-1 7-8 9-13 2 5 5 12 9 13" />
      <path d="M16 8v13" />
      <path d="M12 16h8" />
    </svg>
  );
}
