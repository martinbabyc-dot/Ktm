import { useEffect, useRef, useState } from "react";
import { Camera, Crosshair, MonitorPlay, Square, Upload } from "lucide-react";
import { toast } from "sonner";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Badge } from "@/components/ui/badge";
import { classifyPixel, formatMultiplier, type IceColor } from "@/lib/analyzer";
import { extractMultipliersFromImage, frameToCanvas } from "@/lib/ocr";
import { useSession } from "@/store/session";
import { cn } from "@/lib/utils";

const TONE: Record<IceColor, "red" | "green" | "gold" | "mute"> = {
  RED: "red",
  GREEN: "green",
  GOLD: "gold",
  UNKNOWN: "mute",
};

function readPixel(
  canvas: HTMLCanvasElement,
  nx: number,
  ny: number,
): { r: number; g: number; b: number; x: number; y: number; color: IceColor } | null {
  const ctx = canvas.getContext("2d", { willReadFrequently: true });
  if (!ctx) return null;
  const x = Math.min(canvas.width - 1, Math.max(0, Math.round(nx * canvas.width)));
  const y = Math.min(canvas.height - 1, Math.max(0, Math.round(ny * canvas.height)));
  const data = ctx.getImageData(x, y, 1, 1).data;
  const r = data[0] ?? 0;
  const g = data[1] ?? 0;
  const b = data[2] ?? 0;
  return { r, g, b, x, y, color: classifyPixel(r, g, b) };
}

export function CaptureLab() {
  const samplePoint = useSession((s) => s.samplePoint);
  const setSamplePoint = useSession((s) => s.setSamplePoint);
  const logColor = useSession((s) => s.logColor);
  const logMany = useSession((s) => s.logMany);
  const logMultiplier = useSession((s) => s.logMultiplier);
  const lastColor = useSession((s) => s.lastColor);

  const videoRef = useRef<HTMLVideoElement>(null);
  const canvasRef = useRef<HTMLCanvasElement>(null);
  const fileRef = useRef<HTMLInputElement>(null);
  const streamRef = useRef<MediaStream | null>(null);
  const timerRef = useRef<number | null>(null);

  const [mounted, setMounted] = useState(false);
  const [sharing, setSharing] = useState(false);
  const [busy, setBusy] = useState(false);
  const [previewUrl, setPreviewUrl] = useState<string | null>(null);
  const [probe, setProbe] = useState("Tap the image to sample color");

  useEffect(() => {
    setMounted(true);
    return () => {
      if (timerRef.current) window.clearInterval(timerRef.current);
      streamRef.current?.getTracks().forEach((t) => t.stop());
    };
  }, []);

  useEffect(() => {
    if (!previewUrl) return;
    const image = new Image();
    image.onload = () => {
      const canvas = canvasRef.current;
      if (!canvas) return;
      const scale = Math.min(1, 960 / image.width);
      canvas.width = Math.max(1, Math.round(image.width * scale));
      canvas.height = Math.max(1, Math.round(image.height * scale));
      const ctx = canvas.getContext("2d");
      if (!ctx) return;
      ctx.drawImage(image, 0, 0, canvas.width, canvas.height);
    };
    image.src = previewUrl;
  }, [previewUrl]);

  function stopShare() {
    if (timerRef.current) {
      window.clearInterval(timerRef.current);
      timerRef.current = null;
    }
    streamRef.current?.getTracks().forEach((t) => t.stop());
    streamRef.current = null;
    const video = videoRef.current;
    if (video) video.srcObject = null;
    setSharing(false);
  }

  async function startShare() {
    if (!navigator.mediaDevices?.getDisplayMedia) {
      toast("Screen share is not available in this browser");
      return;
    }
    try {
      const stream = await navigator.mediaDevices.getDisplayMedia({
        video: { frameRate: 8 },
        audio: false,
      });
      streamRef.current = stream;
      const video = videoRef.current;
      if (!video) return;
      video.srcObject = stream;
      await video.play();
      setSharing(true);
      stream.getVideoTracks()[0]?.addEventListener("ended", () => stopShare());
      timerRef.current = window.setInterval(() => {
        sampleLiveColor();
      }, 700);
    } catch (error) {
      const message = error instanceof Error ? error.message : "Screen share was blocked";
      toast(message);
    }
  }

  function sampleLiveColor() {
    const video = videoRef.current;
    if (!video || video.readyState < 2) return;
    try {
      const canvas = frameToCanvas(video, 640);
      const hit = readPixel(canvas, samplePoint.x, samplePoint.y);
      if (!hit) return;
      setProbe(`${hit.color}  rgb(${hit.r}, ${hit.g}, ${hit.b})`);
      if (hit.color !== "UNKNOWN" && hit.color !== lastColor) {
        logColor({ ...hit, x: samplePoint.x, y: samplePoint.y });
      }
    } catch {
      /* frame not ready */
    }
  }

  async function scanFrame() {
    const video = videoRef.current;
    if (!video || video.readyState < 2) {
      toast("Start screen share first");
      return;
    }
    setBusy(true);
    try {
      const canvas = frameToCanvas(video, 960);
      const { multipliers, text } = await extractMultipliersFromImage(canvas);
      if (multipliers.length === 0) {
        toast(text.trim() ? "No multipliers in that frame" : "OCR found no text");
        return;
      }
      let added = 0;
      for (const value of multipliers) {
        if (logMultiplier(value, "ocr", true)) added += 1;
      }
      toast(added > 0 ? `Read ${multipliers.map((m) => formatMultiplier(m)).join(", ")}` : "Already logged");
    } catch {
      toast("Could not read this frame — paste history instead");
    } finally {
      setBusy(false);
    }
  }

  function onPickImage(file: File) {
    const url = URL.createObjectURL(file);
    setPreviewUrl((prev) => {
      if (prev) URL.revokeObjectURL(prev);
      return url;
    });
  }

  function onCanvasClick(event: React.MouseEvent<HTMLCanvasElement>) {
    const canvas = event.currentTarget;
    const rect = canvas.getBoundingClientRect();
    const nx = (event.clientX - rect.left) / rect.width;
    const ny = (event.clientY - rect.top) / rect.height;
    setSamplePoint(nx, ny);
    const hit = readPixel(canvas, nx, ny);
    if (!hit) return;
    const color = logColor({ ...hit, x: nx, y: ny });
    setProbe(`${color}  rgb(${hit.r}, ${hit.g}, ${hit.b})`);
    toast(`Sampled ${color}`);
  }

  async function readScreenshot() {
    const canvas = canvasRef.current;
    if (!canvas || canvas.width === 0) {
      toast("Drop a screenshot first");
      return;
    }
    setBusy(true);
    try {
      const { multipliers } = await extractMultipliersFromImage(canvas);
      if (multipliers.length === 0) {
        toast("No 1.23x-style values found");
        return;
      }
      const n = logMany(multipliers, "ocr");
      toast(`Read ${n} multiplier${n === 1 ? "" : "s"}`);
    } catch {
      toast("OCR failed — paste the history text instead");
    } finally {
      setBusy(false);
    }
  }

  return (
    <Card className="p-4 sm:p-5">
      <CardHeader>
        <div>
          <CardTitle>Screen lab</CardTitle>
          <CardDescription className="mt-1">
            Drop a screenshot or share a window. Click to sample Ice color; scan to OCR visible
            multipliers such as 5.45x.
          </CardDescription>
        </div>
        <Badge tone={TONE[lastColor]}>{lastColor}</Badge>
      </CardHeader>

      <div className="mb-3 flex flex-wrap gap-2">
        {sharing ? (
          <Button variant="secondary" onClick={stopShare}>
            <Square />
            Stop share
          </Button>
        ) : (
          <Button variant="secondary" onClick={startShare}>
            <MonitorPlay />
            Share screen
          </Button>
        )}
        <Button variant="secondary" onClick={scanFrame} disabled={!sharing || busy}>
          <Camera />
          Scan frame
        </Button>
        <Button variant="outline" onClick={() => fileRef.current?.click()}>
          <Upload />
          Screenshot
        </Button>
        <Button variant="ghost" onClick={readScreenshot} disabled={busy || !previewUrl}>
          Read image
        </Button>
        {mounted ? (
          <input
            ref={fileRef}
            type="file"
            accept="image/*"
            className="hidden"
            onChange={(e) => {
              const file = e.target.files?.[0];
              if (file) onPickImage(file);
              e.target.value = "";
            }}
          />
        ) : null}
      </div>

      <p className="mb-3 flex items-center gap-2 text-xs text-muted">
        <Crosshair className="size-3.5 text-accent" />
        {probe}
      </p>

      <div className="grid gap-3 lg:grid-cols-2">
        <div className="relative overflow-hidden rounded-2xl bg-surface-2 shadow-[inset_0_0_0_1px_rgba(232,236,239,0.06)]">
          <video
            ref={videoRef}
            className={cn("block w-full bg-bg", sharing ? "aspect-video" : "hidden")}
            muted
            playsInline
            onClick={(event) => {
              const video = event.currentTarget;
              const rect = video.getBoundingClientRect();
              setSamplePoint(
                (event.clientX - rect.left) / rect.width,
                (event.clientY - rect.top) / rect.height,
              );
              sampleLiveColor();
            }}
          />
          {sharing ? (
            <span className="absolute left-3 top-3 inline-flex items-center gap-2 rounded-full bg-bg/80 px-2.5 py-1 text-[11px] uppercase tracking-[0.14em] text-accent">
              <span className="live-dot size-1.5 rounded-full bg-accent" />
              Live
            </span>
          ) : (
            <div className="flex aspect-video items-center justify-center px-6 text-center text-sm text-muted">
              Share a window to sample color live. If share is blocked, drop a screenshot instead.
            </div>
          )}
        </div>

        <div className="relative overflow-hidden rounded-2xl bg-surface-2 shadow-[inset_0_0_0_1px_rgba(232,236,239,0.06)]">
          {previewUrl ? (
            <canvas
              ref={canvasRef}
              className="block w-full cursor-crosshair"
              onClick={onCanvasClick}
            />
          ) : (
            <button
              type="button"
              onClick={() => fileRef.current?.click()}
              onDragOver={(e) => {
                e.preventDefault();
              }}
              onDrop={(e) => {
                e.preventDefault();
                const file = e.dataTransfer.files?.[0];
                if (file && file.type.startsWith("image/")) onPickImage(file);
              }}
              className="flex aspect-video w-full items-center justify-center px-6 text-center text-sm text-muted"
            >
              Drop or choose a screenshot, then click the Ice color.
            </button>
          )}
        </div>
      </div>
    </Card>
  );
}
