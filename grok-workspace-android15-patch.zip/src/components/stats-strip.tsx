import { computeStats, formatGap, formatMultiplier, formatPct } from "@/lib/analyzer";
import { useSession } from "@/store/session";
import { cn } from "@/lib/utils";

function Stat({
  label,
  value,
  hint,
  accent = false,
}: {
  label: string;
  value: string;
  hint?: string;
  accent?: boolean;
}) {
  return (
    <div className="rounded-2xl bg-surface p-4 shadow-[0_0_0_1px_rgba(232,236,239,0.08)]">
      <div className="text-[11px] uppercase tracking-[0.16em] text-faint">{label}</div>
      <div
        className={cn(
          "mt-2 font-mono text-2xl font-medium tabular-nums tracking-tight",
          accent ? "text-accent" : "text-fg",
        )}
      >
        {value}
      </div>
      {hint ? <div className="mt-1 text-xs text-muted">{hint}</div> : null}
    </div>
  );
}

export function StatsStrip() {
  const rounds = useSession((s) => s.rounds);
  const stats = computeStats(rounds);

  return (
    <div className="stagger-in grid grid-cols-2 gap-2 sm:grid-cols-3 xl:grid-cols-6">
      <Stat label="Rounds" value={String(stats.rounds)} hint="Stored locally" />
      <Stat
        label="Last"
        value={stats.lastMultiplier === null ? "—" : formatMultiplier(stats.lastMultiplier)}
      />
      <Stat
        label="Average"
        value={stats.average === null ? "—" : formatMultiplier(stats.average)}
        hint={stats.median === null ? undefined : `Median ${formatMultiplier(stats.median)}`}
      />
      <Stat
        label="Since 5x"
        value={formatGap(stats.roundsSince5x)}
        hint="Rounds after last ≥5x"
        accent
      />
      <Stat
        label="Since 10x"
        value={formatGap(stats.roundsSince10x)}
        hint="Rounds after last ≥10x"
      />
      <Stat
        label="Under 2x"
        value={formatPct(stats.pctBelow2)}
        hint={
          stats.pctAtLeast5 === null ? undefined : `${formatPct(stats.pctAtLeast5)} at 5x+`
        }
      />
    </div>
  );
}
