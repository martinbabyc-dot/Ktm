import { useMemo, useState } from "react";
import { toast } from "sonner";
import { ClipboardPaste, Delete, Undo2 } from "lucide-react";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Textarea } from "@/components/ui/input";
import { parseMultiplierToken, parseMultipliers } from "@/lib/analyzer";
import { useSession } from "@/store/session";
import { cn } from "@/lib/utils";

const KEYS = ["1", "2", "3", "4", "5", "6", "7", "8", "9", ".", "0", "log"] as const;
const CHIPS = [1.01, 1.2, 1.5, 2, 3, 5, 10, 20];

export function RoundPad() {
  const logMultiplier = useSession((s) => s.logMultiplier);
  const logMany = useSession((s) => s.logMany);
  const undoLastRound = useSession((s) => s.undoLastRound);
  const rounds = useSession((s) => s.rounds);
  const [buffer, setBuffer] = useState("");
  const [paste, setPaste] = useState("");

  const preview = useMemo(() => parseMultiplierToken(buffer), [buffer]);

  function pushKey(key: string) {
    if (key === "log") {
      commit(buffer);
      return;
    }
    setBuffer((current) => {
      if (key === "." && current.includes(".")) return current;
      if (key === "." && current.length === 0) return "0.";
      const next = current + key;
      const [whole, frac] = next.split(".");
      if ((whole?.length ?? 0) > 5) return current;
      if (frac && frac.length > 3) return current;
      return next;
    });
  }

  function commit(raw: string) {
    const value = parseMultiplierToken(raw);
    if (value === null) {
      toast("Enter a multiplier of 1.00x or higher");
      return;
    }
    if (logMultiplier(value, "manual")) {
      toast(`Logged ${value.toFixed(2)}x`);
      setBuffer("");
    }
  }

  function pasteIn() {
    const values = parseMultipliers(paste);
    if (values.length === 0) {
      toast("No multipliers found — try 1.23x 2.10x");
      return;
    }
    const n = logMany(values, "paste");
    toast(`Imported ${n} round${n === 1 ? "" : "s"}`);
    setPaste("");
  }

  return (
    <Card className="p-4 sm:p-5">
      <CardHeader className="pb-4">
        <div>
          <CardTitle>Log a round</CardTitle>
          <CardDescription className="mt-1">
            Type the crashed multiplier, or paste a list from the game history.
          </CardDescription>
        </div>
        <Button
          variant="ghost"
          size="sm"
          onClick={undoLastRound}
          disabled={rounds.length === 0}
          aria-label="Undo last round"
        >
          <Undo2 />
          Undo
        </Button>
      </CardHeader>

      <div className="mb-3 flex h-16 items-center justify-between rounded-2xl bg-surface-2 px-4 shadow-[inset_0_0_0_1px_rgba(232,236,239,0.06)]">
        <span className="text-[11px] uppercase tracking-[0.16em] text-faint">Next</span>
        <span className="font-mono text-3xl font-medium tabular-nums tracking-tight text-fg">
          {buffer.length > 0 ? `${buffer}x` : preview !== null ? `${preview.toFixed(2)}x` : "—.––x"}
        </span>
      </div>

      <div className="mb-3 flex flex-wrap gap-1.5">
        {CHIPS.map((value) => (
          <button
            key={value}
            type="button"
            onClick={() => {
              if (logMultiplier(value, "manual")) toast(`Logged ${value.toFixed(2)}x`);
            }}
            className="h-9 rounded-full bg-surface-2 px-3 font-mono text-xs tabular-nums text-muted shadow-[0_0_0_1px_rgba(232,236,239,0.08)] transition-[background-color,color,scale] duration-150 ease-out hover:bg-surface-3 hover:text-fg active:scale-[0.96]"
          >
            {value.toFixed(2)}x
          </button>
        ))}
      </div>

      <div className="grid grid-cols-3 gap-2">
        {KEYS.map((key) => (
          <Button
            key={key}
            variant={key === "log" ? "default" : "secondary"}
            size="key"
            className={cn(key === "log" && "font-sans text-sm tracking-wide uppercase")}
            onClick={() => pushKey(key)}
          >
            {key === "log" ? "Log" : key}
          </Button>
        ))}
      </div>
      <div className="mt-2">
        <Button
          variant="ghost"
          size="sm"
          className="w-full"
          onClick={() => setBuffer((b) => b.slice(0, -1))}
          disabled={buffer.length === 0}
        >
          <Delete />
          Backspace
        </Button>
      </div>

      <div className="mt-5 space-y-2">
        <label htmlFor="paste-history" className="text-[11px] uppercase tracking-[0.16em] text-faint">
          Paste history
        </label>
        <Textarea
          id="paste-history"
          value={paste}
          onChange={(e) => setPaste(e.target.value)}
          placeholder="1.23x  4.50x  2.01x"
        />
        <Button variant="secondary" className="w-full" onClick={pasteIn} disabled={!paste.trim()}>
          <ClipboardPaste />
          Import pasted rounds
        </Button>
      </div>
    </Card>
  );
}
