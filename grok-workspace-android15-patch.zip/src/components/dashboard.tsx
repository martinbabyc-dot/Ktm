import { useEffect, useState } from "react";
import { Download, Eraser, Layers } from "lucide-react";
import { Toaster, toast } from "sonner";
import { CaptureLab } from "@/components/capture-lab";
import { HeroReadout } from "@/components/hero-readout";
import { HistoryPanel } from "@/components/history-panel";
import { IceTrack } from "@/components/ice-track";
import { PlaneMark } from "@/components/mark";
import { RoundPad } from "@/components/round-pad";
import { StatsStrip } from "@/components/stats-strip";
import { Button } from "@/components/ui/button";
import { colorsToCsv, roundsToCsv } from "@/lib/analyzer";
import { useSession } from "@/store/session";

function downloadText(filename: string, contents: string) {
  const blob = new Blob([contents], { type: "text/csv;charset=utf-8" });
  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = filename;
  a.click();
  URL.revokeObjectURL(url);
}

export function Dashboard() {
  const rounds = useSession((s) => s.rounds);
  const colors = useSession((s) => s.colors);
  const loadSample = useSession((s) => s.loadSample);
  const clearAll = useSession((s) => s.clearAll);
  const [confirmClear, setConfirmClear] = useState(false);

  useEffect(() => {
    void useSession.persist.rehydrate();
  }, []);

  function exportCsv() {
    downloadText("ice-analyzer-rounds.csv", roundsToCsv(rounds));
    if (colors.length > 0) downloadText("ice-analyzer-colors.csv", colorsToCsv(colors));
    toast("Exported CSV");
  }

  return (
    <main className="mx-auto min-h-dvh max-w-6xl px-4 pb-16 pt-6 sm:px-6 sm:pt-8">
      <Toaster
        theme="dark"
        position="bottom-center"
        toastOptions={{
          style: {
            background: "#12151a",
            color: "#e8ecef",
            border: "1px solid rgba(232,236,239,0.12)",
          },
        }}
      />

      <header className="mb-6 flex flex-col gap-4 sm:mb-8 sm:flex-row sm:items-end sm:justify-between">
        <div>
          <div className="flex items-center gap-2">
            <PlaneMark className="size-6" />
            <p className="text-[11px] uppercase tracking-[0.22em] text-accent">Aviator · Ice</p>
          </div>
          <h1 className="mt-2 text-3xl font-medium tracking-tight text-fg sm:text-4xl">
            Ice Analyzer
          </h1>
          <p className="mt-2 max-w-xl text-sm leading-normal text-muted">
            Record visible multipliers and Ice colors, then review gaps, averages, and distribution.
            This does not predict the next round.
          </p>
        </div>
        <div className="flex flex-wrap gap-2">
          <Button
            variant="secondary"
            size="sm"
            onClick={() => {
              loadSample();
              toast("Loaded a sample session");
            }}
          >
            <Layers />
            Sample session
          </Button>
          <Button variant="secondary" size="sm" onClick={exportCsv} disabled={rounds.length === 0}>
            <Download />
            Export CSV
          </Button>
          <Button
            variant={confirmClear ? "danger" : "ghost"}
            size="sm"
            onClick={() => {
              if (!confirmClear) {
                setConfirmClear(true);
                window.setTimeout(() => setConfirmClear(false), 2500);
                return;
              }
              clearAll();
              setConfirmClear(false);
              toast("Session cleared");
            }}
            disabled={rounds.length === 0 && colors.length === 0}
          >
            <Eraser />
            {confirmClear ? "Confirm clear" : "Clear"}
          </Button>
        </div>
      </header>

      <div className="grid gap-3 lg:grid-cols-[minmax(0,0.9fr)_minmax(0,1.1fr)]">
        <div className="grid gap-3">
          <HeroReadout />
          <RoundPad />
        </div>
        <div className="grid gap-3">
          <StatsStrip />
          <HistoryPanel />
        </div>
      </div>

      <div className="mt-3 grid gap-3 lg:grid-cols-2">
        <IceTrack />
        <CaptureLab />
      </div>

      <footer className="mt-10 max-w-2xl text-xs leading-relaxed text-faint">
        Ice Analyzer records what you log or what is visible in a screenshot you provide. Crash games
        are random; historical gaps since 5x or 10x are not a forecast. Nothing here places bets or
        automates cash-out.
      </footer>
    </main>
  );
}
