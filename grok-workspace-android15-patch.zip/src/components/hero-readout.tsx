import { computeStats, formatGap, formatMultiplier } from "@/lib/analyzer";
import { PlaneMark } from "@/components/mark";
import { Badge } from "@/components/ui/badge";
import { useSession } from "@/store/session";

const COLOR_TONE = {
  RED: "red",
  GREEN: "green",
  GOLD: "gold",
  UNKNOWN: "mute",
} as const;

export function HeroReadout() {
  const rounds = useSession((s) => s.rounds);
  const lastColor = useSession((s) => s.lastColor);
  const stats = computeStats(rounds);
  const last = stats.lastMultiplier;
  const lastId = rounds[rounds.length - 1]?.id ?? "empty";

  return (
    <section className="relative overflow-hidden rounded-3xl bg-surface p-5 shadow-[0_0_0_1px_rgba(232,236,239,0.08)] sm:p-7">
      <div className="absolute inset-x-8 top-[46%] h-px bg-accent/30" />
      <div className="relative flex items-start justify-between gap-4">
        <div className="flex items-center gap-2 text-muted">
          <PlaneMark className="size-7" />
          <span className="text-[11px] uppercase tracking-[0.2em]">Last recorded</span>
        </div>
        <Badge tone={COLOR_TONE[lastColor]}>Ice {lastColor}</Badge>
      </div>
      <div key={lastId} className="readout-pop relative mt-6 font-mono font-medium tabular-nums tracking-tight">
        <span className="block text-[clamp(3.4rem,12vw,6.5rem)] leading-none text-fg">
          {last === null ? "—.––" : last.toFixed(2)}
          <span className="text-accent">x</span>
        </span>
      </div>
      <dl className="relative mt-6 grid grid-cols-3 gap-3 text-sm">
        <div>
          <dt className="text-[11px] uppercase tracking-[0.16em] text-faint">Since 5x</dt>
          <dd className="mt-1 font-mono tabular-nums text-accent">{formatGap(stats.roundsSince5x)}</dd>
        </div>
        <div>
          <dt className="text-[11px] uppercase tracking-[0.16em] text-faint">Since 10x</dt>
          <dd className="mt-1 font-mono tabular-nums text-fg">{formatGap(stats.roundsSince10x)}</dd>
        </div>
        <div>
          <dt className="text-[11px] uppercase tracking-[0.16em] text-faint">Average</dt>
          <dd className="mt-1 font-mono tabular-nums text-fg">
            {stats.average === null ? "—" : formatMultiplier(stats.average)}
          </dd>
        </div>
      </dl>
    </section>
  );
}
