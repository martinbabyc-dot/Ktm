import { formatDistanceToNowStrict } from "date-fns";
import {
  Bar,
  BarChart,
  ResponsiveContainer,
  Tooltip,
  XAxis,
  YAxis,
} from "recharts";
import { bucketCounts, formatMultiplier } from "@/lib/analyzer";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { useSession } from "@/store/session";
import { cn } from "@/lib/utils";

function multiplierTone(value: number): string {
  if (value >= 10) return "text-accent";
  if (value >= 5) return "text-fg";
  if (value < 2) return "text-muted";
  return "text-fg";
}

export function HistoryPanel() {
  const rounds = useSession((s) => s.rounds);
  const buckets = bucketCounts(rounds);
  const recent = [...rounds].reverse().slice(0, 40);

  return (
    <div className="grid gap-3">
      <Card className="p-4 sm:p-5">
        <CardHeader>
          <div>
            <CardTitle>Distribution</CardTitle>
            <CardDescription className="mt-1">
              Crash ranges, labeled by the top of each bucket.
            </CardDescription>
          </div>
        </CardHeader>
        {rounds.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">Log rounds to see the spread.</p>
        ) : (
          <div className="h-48">
            <ResponsiveContainer width="100%" height="100%">
              <BarChart data={buckets} margin={{ top: 8, right: 8, left: -22, bottom: 0 }}>
                <XAxis
                  dataKey="label"
                  interval={0}
                  tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <YAxis
                  allowDecimals={false}
                  width={28}
                  tick={{ fill: "var(--color-muted)", fontSize: 11 }}
                  axisLine={false}
                  tickLine={false}
                />
                <Tooltip
                  cursor={{ fill: "color-mix(in oklab, var(--color-fg) 6%, transparent)" }}
                  contentStyle={{
                    background: "var(--color-surface)",
                    border: "1px solid color-mix(in oklab, var(--color-fg) 12%, transparent)",
                    borderRadius: 12,
                    color: "var(--color-fg)",
                    fontSize: 12,
                  }}
                />
                <Bar dataKey="count" fill="var(--color-accent)" radius={[6, 6, 0, 0]} />
              </BarChart>
            </ResponsiveContainer>
          </div>
        )}
      </Card>

      <Card className="p-4 sm:p-5">
        <CardHeader>
          <div>
            <CardTitle>Round history</CardTitle>
            <CardDescription className="mt-1">Newest first. Up to 500 rounds are kept.</CardDescription>
          </div>
          <span className="font-mono text-xs tabular-nums text-muted">{rounds.length}</span>
        </CardHeader>
        {recent.length === 0 ? (
          <p className="py-10 text-center text-sm text-muted">No rounds yet.</p>
        ) : (
          <ol className="max-h-[28rem] divide-y divide-border overflow-auto">
            {recent.map((round) => (
              <li key={round.id} className="flex items-center justify-between gap-3 py-2.5">
                <span
                  className={cn(
                    "font-mono text-base font-medium tabular-nums",
                    multiplierTone(round.multiplier),
                  )}
                >
                  {formatMultiplier(round.multiplier)}
                </span>
                <span className="text-xs text-muted">
                  {formatDistanceToNowStrict(round.timeMillis, { addSuffix: true })}
                  <span className="ml-2 uppercase tracking-wide text-faint">{round.source}</span>
                </span>
              </li>
            ))}
          </ol>
        )}
      </Card>
    </div>
  );
}
