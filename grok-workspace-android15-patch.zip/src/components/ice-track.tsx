import { Badge } from "@/components/ui/badge";
import { Button } from "@/components/ui/button";
import { Card, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import type { IceColor } from "@/lib/analyzer";
import { useSession } from "@/store/session";
import { cn } from "@/lib/utils";

const TONES: Record<IceColor, "red" | "green" | "gold" | "mute"> = {
  RED: "red",
  GREEN: "green",
  GOLD: "gold",
  UNKNOWN: "mute",
};

const SWATCH: Record<IceColor, string> = {
  RED: "bg-ice-red",
  GREEN: "bg-ice-green",
  GOLD: "bg-ice-gold",
  UNKNOWN: "bg-faint",
};

const MANUAL: IceColor[] = ["RED", "GREEN", "GOLD"];

export function IceTrack() {
  const colors = useSession((s) => s.colors);
  const lastColor = useSession((s) => s.lastColor);
  const logColor = useSession((s) => s.logColor);
  const counts = {
    RED: colors.filter((c) => c.color === "RED").length,
    GREEN: colors.filter((c) => c.color === "GREEN").length,
    GOLD: colors.filter((c) => c.color === "GOLD").length,
  };
  const recent = [...colors].reverse().slice(0, 24);

  return (
    <Card className="p-4 sm:p-5">
      <CardHeader>
        <div>
          <CardTitle>Ice color track</CardTitle>
          <CardDescription className="mt-1">
            Log Red / Green / Gold from Ice, or sample a pixel on a screenshot. Classification matches
            the original analyzer.
          </CardDescription>
        </div>
        <Badge tone={TONES[lastColor]}>{lastColor}</Badge>
      </CardHeader>

      <div className="mb-4 grid grid-cols-3 gap-2">
        {MANUAL.map((color) => (
          <Button
            key={color}
            variant="secondary"
            onClick={() =>
              logColor({
                color,
                r: color === "RED" ? 210 : 80,
                g: color === "GREEN" ? 170 : 90,
                b: 50,
                x: 0,
                y: 0,
              })
            }
          >
            {color}
          </Button>
        ))}
      </div>

      <div className="mb-4 flex flex-wrap gap-2 text-xs text-muted">
        <span>Red {counts.RED}</span>
        <span className="text-faint">·</span>
        <span>Green {counts.GREEN}</span>
        <span className="text-faint">·</span>
        <span>Gold {counts.GOLD}</span>
      </div>

      {recent.length === 0 ? (
        <p className="py-6 text-center text-sm text-muted">No color samples yet.</p>
      ) : (
        <ol className="flex flex-wrap gap-1.5">
          {recent.map((event) => (
            <li
              key={event.id}
              title={event.color}
              className={cn("size-4 rounded-full", SWATCH[event.color])}
            />
          ))}
        </ol>
      )}
    </Card>
  );
}
