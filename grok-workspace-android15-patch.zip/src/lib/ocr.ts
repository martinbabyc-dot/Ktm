import { parseMultipliers } from "@/lib/analyzer";

type TessWorker = {
  setParameters: (params: Record<string, string>) => Promise<void>;
  recognize: (image: HTMLCanvasElement | HTMLImageElement | File | Blob | string) => Promise<{
    data: { text: string };
  }>;
  terminate: () => Promise<void>;
};

let workerPromise: Promise<TessWorker> | null = null;

async function getWorker(): Promise<TessWorker> {
  if (workerPromise) return workerPromise;
  workerPromise = (async () => {
    const { createWorker } = await import("tesseract.js");
    const worker = (await createWorker("eng", 1, {
      workerPath: "https://cdn.jsdelivr.net/npm/tesseract.js@5/dist/worker.min.js",
      corePath: "https://cdn.jsdelivr.net/npm/tesseract.js-core@5/tesseract-core-simd.wasm.js",
      langPath: "https://tessdata.projectnaptha.com/4.0.0",
    })) as unknown as TessWorker;
    await worker.setParameters({
      tessedit_char_whitelist: "0123456789.,xX ",
    });
    return worker;
  })();
  return workerPromise;
}

export async function extractMultipliersFromImage(
  image: HTMLCanvasElement | HTMLImageElement | File | Blob | string,
): Promise<{ text: string; multipliers: number[] }> {
  const worker = await getWorker();
  const result = await worker.recognize(image);
  const text = result.data.text ?? "";
  return { text, multipliers: parseMultipliers(text) };
}

export function frameToCanvas(
  video: HTMLVideoElement,
  maxWidth = 960,
): HTMLCanvasElement {
  const vw = video.videoWidth || 1;
  const vh = video.videoHeight || 1;
  const scale = Math.min(1, maxWidth / vw);
  const canvas = document.createElement("canvas");
  canvas.width = Math.max(1, Math.round(vw * scale));
  canvas.height = Math.max(1, Math.round(vh * scale));
  const ctx = canvas.getContext("2d");
  if (!ctx) throw new Error("Canvas is unavailable");
  ctx.drawImage(video, 0, 0, canvas.width, canvas.height);
  return canvas;
}
