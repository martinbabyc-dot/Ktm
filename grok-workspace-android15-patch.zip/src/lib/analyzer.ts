export type RoundSource = "manual" | "paste" | "ocr" | "sample";

export type RoundRecord = {
  id: string;
  multiplier: number;
  timeMillis: number;
  source: RoundSource;
};

export type IceColor = "RED" | "GREEN" | "GOLD" | "UNKNOWN";

export type ColorEvent = {
  id: string;
  color: IceColor;
  r: number;
  g: number;
  b: number;
  x: number;
  y: number;
  timeMillis: number;
};

export type Stats = {
  rounds: number;
  lastMultiplier: number | null;
  roundsSince5x: number | null;
  roundsSince10x: number | null;
  roundsSince20x: number | null;
  average: number | null;
  median: number | null;
  max: number | null;
  min: number | null;
  pctBelow2: number | null;
  pctAtLeast5: number | null;
  pctAtLeast10: number | null;
};

export const HISTORY_CAP = 500;

export const BUCKETS = [
  { key: "1-1.5", label: "1.5", min: 1, max: 1.5 },
  { key: "1.5-2", label: "2", min: 1.5, max: 2 },
  { key: "2-3", label: "3", min: 2, max: 3 },
  { key: "3-5", label: "5", min: 3, max: 5 },
  { key: "5-10", label: "10", min: 5, max: 10 },
  { key: "10-20", label: "20", min: 10, max: 20 },
  { key: "20+", label: "20+", min: 20, max: Infinity },
] as const;

const MULTIPLIER_X_RE =
  /(?<!\d)(\d{1,5}(?:[.,]\d{1,3})?)\s*[xX](?!\w)/g;
const BARE_NUMBER_RE = /^\s*(\d{1,5}(?:[.,]\d{1,3})?)\s*$/;

export function isValidMultiplier(value: number): boolean {
  return Number.isFinite(value) && value >= 1 && value <= 100_000;
}

export function parseMultiplierToken(raw: string): number | null {
  const n = Number.parseFloat(raw.trim().replace(",", "."));
  return isValidMultiplier(n) ? n : null;
}

export function parseMultipliers(text: string): number[] {
  const found: number[] = [];
  const seen = new Set<string>();

  const push = (value: number) => {
    const key = value.toFixed(3);
    if (seen.has(key)) return;
    seen.add(key);
    found.push(value);
  };

  for (const match of text.matchAll(MULTIPLIER_X_RE)) {
    const value = parseMultiplierToken(match[1] ?? "");
    if (value !== null) push(value);
  }

  if (found.length > 0) return found;

  for (const line of text.split(/[\n,;\t]+/)) {
    const trimmed = line.trim();
    if (!trimmed) continue;
    const bare = trimmed.match(BARE_NUMBER_RE);
    if (!bare) continue;
    const value = parseMultiplierToken(bare[1] ?? "");
    if (value !== null) found.push(value);
  }

  return found;
}

export function addRound(
  history: RoundRecord[],
  value: number,
  source: RoundSource,
  debounceSame = false,
): RoundRecord[] | null {
  if (!isValidMultiplier(value)) return null;
  if (debounceSame && history.length > 0) {
    const last = history[history.length - 1];
    if (last && Math.abs(last.multiplier - value) < 0.0001) return null;
  }
  const next: RoundRecord = {
    id: crypto.randomUUID(),
    multiplier: value,
    timeMillis: Date.now(),
    source,
  };
  const list = [...history, next];
  if (list.length > HISTORY_CAP) list.splice(0, list.length - HISTORY_CAP);
  return list;
}

function roundsSince(list: RoundRecord[], threshold: number): number | null {
  for (let i = list.length - 1; i >= 0; i -= 1) {
    const round = list[i];
    if (round && round.multiplier >= threshold) return list.length - 1 - i;
  }
  return null;
}

export function computeStats(history: RoundRecord[]): Stats {
  if (history.length === 0) {
    return {
      rounds: 0,
      lastMultiplier: null,
      roundsSince5x: null,
      roundsSince10x: null,
      roundsSince20x: null,
      average: null,
      median: null,
      max: null,
      min: null,
      pctBelow2: null,
      pctAtLeast5: null,
      pctAtLeast10: null,
    };
  }
  const values = history.map((r) => r.multiplier);
  const sorted = [...values].sort((a, b) => a - b);
  const mid = Math.floor(sorted.length / 2);
  const median =
    sorted.length % 2 === 0
      ? ((sorted[mid - 1] ?? 0) + (sorted[mid] ?? 0)) / 2
      : (sorted[mid] ?? 0);
  const n = values.length;
  return {
    rounds: n,
    lastMultiplier: values[n - 1] ?? null,
    roundsSince5x: roundsSince(history, 5),
    roundsSince10x: roundsSince(history, 10),
    roundsSince20x: roundsSince(history, 20),
    average: values.reduce((a, b) => a + b, 0) / n,
    median,
    max: sorted[sorted.length - 1] ?? null,
    min: sorted[0] ?? null,
    pctBelow2: (values.filter((v) => v < 2).length / n) * 100,
    pctAtLeast5: (values.filter((v) => v >= 5).length / n) * 100,
    pctAtLeast10: (values.filter((v) => v >= 10).length / n) * 100,
  };
}

export function bucketCounts(history: RoundRecord[]): { key: string; label: string; count: number }[] {
  return BUCKETS.map((bucket) => ({
    key: bucket.key,
    label: bucket.label,
    count: history.filter((r) => r.multiplier >= bucket.min && r.multiplier < bucket.max).length,
  }));
}

export function classifyPixel(r: number, g: number, b: number): IceColor {
  if (r > 150 && r > g * 1.35 && r > b * 1.35) return "RED";
  if (g > 120 && g > r * 1.2 && g > b * 1.1) return "GREEN";
  if (r > 130 && g > 90 && b < 120 && r > b * 1.25 && g > b * 1.15) return "GOLD";
  return "UNKNOWN";
}

export function formatMultiplier(value: number, digits = 2): string {
  return `${value.toFixed(digits)}x`;
}

export function formatPct(value: number | null): string {
  if (value === null) return "—";
  return `${Math.round(value)}%`;
}

export function formatGap(value: number | null): string {
  if (value === null) return "—";
  return String(value);
}

export function roundsToCsv(history: RoundRecord[]): string {
  const lines = ["timestamp,multiplier,source"];
  for (const round of history) {
    lines.push(`${round.timeMillis},${round.multiplier.toFixed(2)},${round.source}`);
  }
  return lines.join("\n") + "\n";
}

export function colorsToCsv(events: ColorEvent[]): string {
  const lines = ["timestamp,color,r,g,b,x,y"];
  for (const event of events) {
    lines.push(
      `${event.timeMillis},${event.color},${event.r},${event.g},${event.b},${event.x},${event.y}`,
    );
  }
  return lines.join("\n") + "\n";
}

export const SAMPLE_MULTIPLIERS = [
  1.12, 2.04, 1.37, 3.91, 1.08, 1.55, 7.22, 1.19, 2.31, 1.03, 4.18, 1.44, 1.67,
  12.85, 1.22, 2.76, 1.09, 1.88, 3.05, 1.14, 1.41, 5.6, 1.07, 2.19, 1.33, 8.94,
  1.16, 1.72, 2.48, 1.05, 3.33, 1.28, 1.91, 21.4, 1.11, 2.02, 1.58, 4.77, 1.24,
  1.06,
];

export const SAMPLE_COLORS: IceColor[] = [
  "RED",
  "GREEN",
  "RED",
  "GREEN",
  "GOLD",
  "RED",
  "GREEN",
  "RED",
  "GREEN",
  "RED",
];

export function buildSampleSession(now = Date.now()): {
  rounds: RoundRecord[];
  colors: ColorEvent[];
} {
  const rounds: RoundRecord[] = SAMPLE_MULTIPLIERS.map((multiplier, index) => ({
    id: `sample-r-${index}`,
    multiplier,
    timeMillis: now - (SAMPLE_MULTIPLIERS.length - index) * 48_000,
    source: "sample",
  }));
  const colors: ColorEvent[] = SAMPLE_COLORS.map((color, index) => ({
    id: `sample-c-${index}`,
    color,
    r: color === "RED" ? 210 : color === "GREEN" ? 70 : 200,
    g: color === "GREEN" ? 170 : color === "GOLD" ? 150 : 60,
    b: color === "GREEN" ? 90 : 50,
    x: 0,
    y: 0,
    timeMillis: now - (SAMPLE_COLORS.length - index) * 62_000,
  }));
  return { rounds, colors };
}
