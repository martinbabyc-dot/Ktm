import { create } from "zustand";
import { persist } from "zustand/middleware";
import {
  addRound,
  buildSampleSession,
  classifyPixel,
  computeStats,
  type ColorEvent,
  type IceColor,
  type RoundRecord,
  type RoundSource,
  type Stats,
} from "@/lib/analyzer";

type SessionState = {
  rounds: RoundRecord[];
  colors: ColorEvent[];
  samplePoint: { x: number; y: number };
  lastColor: IceColor;
  logMultiplier: (value: number, source: RoundSource, debounceSame?: boolean) => boolean;
  logMany: (values: number[], source: RoundSource) => number;
  undoLastRound: () => void;
  logColor: (input: {
    color?: IceColor;
    r: number;
    g: number;
    b: number;
    x: number;
    y: number;
  }) => IceColor;
  setSamplePoint: (x: number, y: number) => void;
  loadSample: () => void;
  clearAll: () => void;
  stats: () => Stats;
};

export const useSession = create<SessionState>()(
  persist(
    (set, get) => ({
      rounds: [],
      colors: [],
      samplePoint: { x: 0.5, y: 0.35 },
      lastColor: "UNKNOWN",
      logMultiplier: (value, source, debounceSame = false) => {
        const next = addRound(get().rounds, value, source, debounceSame);
        if (!next) return false;
        set({ rounds: next });
        return true;
      },
      logMany: (values, source) => {
        let count = 0;
        let list = get().rounds;
        for (const value of values) {
          const next = addRound(list, value, source, false);
          if (!next) continue;
          list = next;
          count += 1;
        }
        if (count > 0) set({ rounds: list });
        return count;
      },
      undoLastRound: () => {
        const rounds = get().rounds;
        if (rounds.length === 0) return;
        set({ rounds: rounds.slice(0, -1) });
      },
      logColor: ({ color, r, g, b, x, y }) => {
        const resolved = color ?? classifyPixel(r, g, b);
        const event: ColorEvent = {
          id: crypto.randomUUID(),
          color: resolved,
          r,
          g,
          b,
          x,
          y,
          timeMillis: Date.now(),
        };
        const colors = [...get().colors, event];
        if (colors.length > 500) colors.splice(0, colors.length - 500);
        set({ colors, lastColor: resolved, samplePoint: { x, y } });
        return resolved;
      },
      setSamplePoint: (x, y) => set({ samplePoint: { x, y } }),
      loadSample: () => {
        const sample = buildSampleSession();
        set({
          rounds: sample.rounds,
          colors: sample.colors,
          lastColor: sample.colors[sample.colors.length - 1]?.color ?? "UNKNOWN",
        });
      },
      clearAll: () =>
        set({
          rounds: [],
          colors: [],
          lastColor: "UNKNOWN",
        }),
      stats: () => computeStats(get().rounds),
    }),
    {
      name: "ice-analyzer-session-v1",
      skipHydration: true,
      partialize: (state) => ({
        rounds: state.rounds,
        colors: state.colors,
        samplePoint: state.samplePoint,
        lastColor: state.lastColor,
      }),
    },
  ),
);
