# Aviator & Ice Analyzer — native Android project

Features:
- MediaProjection foreground screen capture
- ML Kit text recognition for visible multipliers such as 5.45x
- Local round history and 5x/10x gap statistics
- Configurable X/Y pixel color detection: RED/GREEN/GOLD/UNKNOWN
- Start/Stop controls

This build intentionally reports historical statistics only; it does not predict or automate betting outcomes.

## Build
Use Android Studio with Android SDK 35 and JDK 17. Open this folder and run:
`./gradlew assembleDebug`

The APK will be at `app/build/outputs/apk/debug/app-debug.apk`.
