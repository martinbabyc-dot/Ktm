package com.example.aviatorice

import android.graphics.Bitmap
import android.graphics.Color
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.text.TextRecognition
import com.google.android.gms.tasks.Tasks
import com.google.mlkit.vision.text.latin.TextRecognizerOptions

enum class DetectedColor { RED, GREEN, GOLD, UNKNOWN }

data class ColorPointResult(val color: DetectedColor, val argb: Int, val x: Int, val y: Int)

class ScreenProcessor {
    private val recognizer = TextRecognition.getClient(TextRecognizerOptions.DEFAULT_OPTIONS)

    fun extractMultipliers(bitmap: Bitmap): List<Double> {
        val image = InputImage.fromBitmap(bitmap, 0)
        return try {
            val result = Tasks.await(recognizer.process(image))
            parseMultipliers(result.text)
        } catch (_: Exception) {
            emptyList()
        }
    }

    private fun parseMultipliers(text: String): List<Double> {
        // Accepts common OCR forms: 5.45x, 5,45x, 5.45 X.
        val regex = Regex("""(?<!\d)(\d{1,5}(?:[.,]\d{1,3})?)\s*[xX](?!\w)""")
        return regex.findAll(text)
            .mapNotNull {
                it.groupValues[1].replace(',', '.').toDoubleOrNull()
            }
            .filter { it >= 1.0 && it <= 100000.0 }
            .distinct()
            .toList()
    }

    fun detectColor(bitmap: Bitmap, x: Int, y: Int): ColorPointResult {
        if (x !in 0 until bitmap.width || y !in 0 until bitmap.height) {
            return ColorPointResult(DetectedColor.UNKNOWN, Color.TRANSPARENT, x, y)
        }
        val px = bitmap.getPixel(x, y)
        val r = Color.red(px); val g = Color.green(px); val b = Color.blue(px)
        val color = when {
            r > 150 && r > g * 1.35f && r > b * 1.35f -> DetectedColor.RED
            g > 120 && g > r * 1.20f && g > b * 1.10f -> DetectedColor.GREEN
            r > 130 && g > 90 && b < 120 && r > b * 1.25f && g > b * 1.15f -> DetectedColor.GOLD
            else -> DetectedColor.UNKNOWN
        }
        return ColorPointResult(color, px, x, y)
    }

    fun close() { recognizer.close() }
}
