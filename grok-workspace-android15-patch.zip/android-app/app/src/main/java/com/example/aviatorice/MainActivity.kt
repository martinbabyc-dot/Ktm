package com.example.aviatorice

import android.Manifest
import android.app.Activity
import android.content.*
import android.media.projection.MediaProjectionManager
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.core.content.ContextCompat
import kotlin.math.roundToInt

class MainActivity : ComponentActivity() {
    private val projectionLauncher =
        registerForActivityResult(ActivityResultContracts.StartActivityForResult()) { result ->
            if (result.resultCode == Activity.RESULT_OK && result.data != null) {
                startAnalyzer(result.resultCode, result.data!!)
            }
        }

    private var receiver: BroadcastReceiver? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        if (android.os.Build.VERSION.SDK_INT >= 33) {
            requestPermissions(arrayOf(Manifest.permission.POST_NOTIFICATIONS), 77)
        }
        setContent { AnalyzerScreen(::requestCapture, ::stopAnalyzer) }
    }

    private fun requestCapture(x: Int, y: Int) {
        getPreferences(MODE_PRIVATE).edit().putInt("x", x).putInt("y", y).apply()
        val mgr = getSystemService(MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projectionLauncher.launch(mgr.createScreenCaptureIntent())
    }

    private fun startAnalyzer(code: Int, data: Intent) {
        val x = getPreferences(MODE_PRIVATE).getInt("x", 0)
        val y = getPreferences(MODE_PRIVATE).getInt("y", 0)
        val intent = Intent(this, ScreenCaptureService::class.java).apply {
            action = ScreenCaptureService.ACTION_START
            putExtra(ScreenCaptureService.EXTRA_RESULT_CODE, code)
            putExtra(ScreenCaptureService.EXTRA_RESULT_DATA, data)
            putExtra(ScreenCaptureService.EXTRA_X, x)
            putExtra(ScreenCaptureService.EXTRA_Y, y)
        }
        ContextCompat.startForegroundService(this, intent)
    }

    private fun stopAnalyzer() {
        startService(Intent(this, ScreenCaptureService::class.java).setAction(ScreenCaptureService.ACTION_STOP))
    }

    override fun onStart() {
        super.onStart()
        receiver = object : BroadcastReceiver() {
            override fun onReceive(c: Context?, i: Intent?) {
                val t = i?.getStringExtra(ScreenCaptureService.EXTRA_TEXT) ?: return
                updateUi(t)
            }
        }
        registerReceiver(receiver, IntentFilter(ScreenCaptureService.ACTION_UPDATE), RECEIVER_NOT_EXPORTED)
    }

    private fun updateUi(text: String) {
        AnalyzerState.message.value = text
    }

    override fun onStop() {
        receiver?.let { unregisterReceiver(it) }
        receiver = null
        super.onStop()
    }
}

object AnalyzerState {
    val message = mutableStateOf("Ready")
}

@Composable
private fun AnalyzerScreen(onStart: (Int, Int) -> Unit, onStop: () -> Unit) {
    var x by remember { mutableStateOf("0") }
    var y by remember { mutableStateOf("0") }
    val msg by AnalyzerState.message
    var running by remember { mutableStateOf(false) }

    MaterialTheme {
        Scaffold(
            topBar = { TopAppBar(title = { Text("Aviator & Ice Analyzer") }) }
        ) { pad ->
            LazyColumn(
                modifier = Modifier.padding(pad).padding(16.dp),
                verticalArrangement = Arrangement.spacedBy(12.dp)
            ) {
                item {
                    Text("Screen analysis", style = MaterialTheme.typography.titleLarge)
                    Text(
                        "OCR reads visible multipliers and keeps historical statistics. " +
                        "Color detection checks the selected screen coordinate.",
                        style = MaterialTheme.typography.bodyMedium
                    )
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        OutlinedTextField(x, { x = it.filter(Char::isDigit) }, label={Text("Color X")}, modifier=Modifier.weight(1f))
                        OutlinedTextField(y, { y = it.filter(Char::isDigit) }, label={Text("Color Y")}, modifier=Modifier.weight(1f))
                    }
                }
                item {
                    Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                        Button(enabled=!running, onClick={
                            onStart(x.toIntOrNull() ?: 0, y.toIntOrNull() ?: 0); running=true
                        }) { Text("Start") }
                        OutlinedButton(enabled=running, onClick={
                            onStop(); running=false
                        }) { Text("Stop") }
                    }
                }
                item {
                    Card(Modifier.fillMaxWidth()) {
                        Column(Modifier.padding(16.dp)) {
                            Text("Live result", style=MaterialTheme.typography.titleMedium)
                            Spacer(Modifier.height(8.dp))
                            Text(msg)
                        }
                    }
                }
                item {
                    Text("What this version does", style=MaterialTheme.typography.titleMedium)
                    Text("• MediaProjection foreground capture\n• ML Kit multiplier OCR\n• Round history and 5x/10x gap statistics\n• Configurable pixel color detection: Red / Green / Gold\n• No betting or next-round prediction")
                }
            }
        }
    }
}
