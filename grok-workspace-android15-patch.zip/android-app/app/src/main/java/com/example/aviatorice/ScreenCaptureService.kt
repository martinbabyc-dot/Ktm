package com.example.aviatorice

import android.app.*
import android.content.Context
import android.app.Activity
import android.content.Intent
import android.graphics.Bitmap
import android.hardware.display.DisplayManager
import android.hardware.display.VirtualDisplay
import android.media.ImageReader
import android.media.projection.MediaProjection
import android.media.projection.MediaProjectionManager
import android.os.*
import androidx.core.app.NotificationCompat
import java.util.concurrent.atomic.AtomicBoolean
import java.util.concurrent.Executors

class ScreenCaptureService : Service() {
    companion object {
        const val ACTION_START = "START_CAPTURE"
        const val ACTION_STOP = "STOP_CAPTURE"
        const val EXTRA_RESULT_CODE = "result_code"
        const val EXTRA_RESULT_DATA = "result_data"
        const val EXTRA_X = "color_x"
        const val EXTRA_Y = "color_y"
        const val ACTION_UPDATE = "ANALYZER_UPDATE"
        const val EXTRA_TEXT = "text"
        private const val CHANNEL = "capture"
        private const val NOTIFICATION_ID = 1001
    }

    private val executor = Executors.newSingleThreadExecutor()
    private val processor = ScreenProcessor()
    private val analyzer = GameAnalyzer()
    private var projection: MediaProjection? = null
    private var projectionCallback: MediaProjection.Callback? = null
    private var lastStatusAt = 0L
    private var display: VirtualDisplay? = null
    private var reader: ImageReader? = null
    private val busy = AtomicBoolean(false)
    private var colorX = 0
    private var colorY = 0
    private var lastColor = DetectedColor.UNKNOWN

    override fun onCreate() {
        super.onCreate()
        createChannel()
    }

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        if (intent?.action == ACTION_STOP) {
            stopCapture()
            stopSelf()
            return START_NOT_STICKY
        }
        if (intent?.action == ACTION_START) {
            colorX = intent.getIntExtra(EXTRA_X, 0)
            colorY = intent.getIntExtra(EXTRA_Y, 0)
            val resultCode = intent.getIntExtra(EXTRA_RESULT_CODE, Activity.RESULT_CANCELED)
            val data = if (Build.VERSION.SDK_INT >= 33) {
                intent.getParcelableExtra(EXTRA_RESULT_DATA, Intent::class.java)
            } else {
                @Suppress("DEPRECATION") intent.getParcelableExtra(EXTRA_RESULT_DATA)
            }
            if (data != null && resultCode == Activity.RESULT_OK) {
                try {
                    startCapture(resultCode, data)
                } catch (t: Throwable) {
                    broadcast("ERROR|${t.javaClass.simpleName}: ${t.message ?: "capture start failed"}")
                    stopCapture()
                    stopSelf()
                }
            } else {
                broadcast("ERROR|Screen-capture permission was not granted")
                stopSelf()
            }
        }
        return START_NOT_STICKY
    }

    private fun startCapture(resultCode: Int, data: Intent) {
        startForeground(
            NOTIFICATION_ID,
            NotificationCompat.Builder(this, CHANNEL)
                .setSmallIcon(android.R.drawable.ic_menu_view)
                .setContentTitle("Aviator & Ice Analyzer")
                .setContentText("Screen analysis is running")
                .setOngoing(true)
                .build(),
            if (Build.VERSION.SDK_INT >= 29) android.content.pm.ServiceInfo.FOREGROUND_SERVICE_TYPE_MEDIA_PROJECTION else 0
        )
        stopCapture()
        val mgr = getSystemService(Context.MEDIA_PROJECTION_SERVICE) as MediaProjectionManager
        projection = mgr.getMediaProjection(resultCode, data)
        // Android 14+ requires a callback to be registered before createVirtualDisplay().
        projectionCallback = object : MediaProjection.Callback() {
            override fun onStop() {
                display?.release(); display = null
                reader?.close(); reader = null
                projection = null
                broadcast("STOPPED|Screen capture was stopped by Android or the user")
                stopSelf()
            }
        }
        projection!!.registerCallback(projectionCallback!!, Handler(Looper.getMainLooper()))
        broadcast("CAPTURE_STARTED|Permission accepted; starting screen capture")
        val dm = resources.displayMetrics
        val width = dm.widthPixels
        val height = dm.heightPixels
        val density = dm.densityDpi
        reader = ImageReader.newInstance(width, height, android.graphics.PixelFormat.RGBA_8888, 2)
        reader!!.setOnImageAvailableListener({ ir ->
            if (!busy.compareAndSet(false, true)) {
                ir.acquireLatestImage()?.close()
                return@setOnImageAvailableListener
            }
            val image = ir.acquireLatestImage()
            if (image == null) { busy.set(false); return@setOnImageAvailableListener }
            executor.execute {
                try {
                    val plane = image.planes[0]
                    val rowStride = plane.rowStride
                    val pixelStride = plane.pixelStride
                    val rowPadding = rowStride - pixelStride * width
                    val raw = plane.buffer
                    val full = Bitmap.createBitmap(
                        width + rowPadding / pixelStride, height, Bitmap.Config.ARGB_8888
                    )
                    full.copyPixelsFromBuffer(raw)
                    val bitmap = Bitmap.createBitmap(full, 0, 0, width, height)
                    full.recycle()

                    val color = processor.detectColor(bitmap, colorX, colorY)
                    if (color.color != lastColor) {
                        lastColor = color.color
                        broadcast("${color.color.name}|${color.x}|${color.y}|${color.argb}")
                    }

                    // OCR at most on frames that arrive while worker is free.
                    val multipliers = processor.extractMultipliers(bitmap)
                    if (multipliers.isEmpty()) {
                        val now = System.currentTimeMillis()
                        if (now - lastStatusAt >= 3000L) {
                            lastStatusAt = now
                            broadcast("OCR_WAITING|Capture active; no multiplier text recognized yet")
                        }
                    }
                    multipliers.forEach { if (analyzer.addMultiplier(it)) {
                        val s = analyzer.stats()
                        broadcast("MULTIPLIER|${it}|${s.rounds}|${s.roundsSince5x ?: -1}|${s.roundsSince10x ?: -1}")
                    }}
                    bitmap.recycle()
                } catch (t: Throwable) {
                    broadcast("ERROR|Frame processing ${t.javaClass.simpleName}: ${t.message ?: "unknown error"}")
                } finally {
                    image.close()
                    busy.set(false)
                }
            }
        }, Handler(Looper.getMainLooper()))
        display = projection!!.createVirtualDisplay(
            "AnalyzerCapture", width, height, density,
            DisplayManager.VIRTUAL_DISPLAY_FLAG_AUTO_MIRROR,
            reader!!.surface, null, null
        )
    }

    private fun broadcast(text: String) {
        sendBroadcast(Intent(ACTION_UPDATE).setPackage(packageName).putExtra(EXTRA_TEXT, text))
    }

    private fun stopCapture() {
        display?.release(); display = null
        reader?.close(); reader = null
        val p = projection
        val cb = projectionCallback
        projection = null
        projectionCallback = null
        if (p != null) {
            try { if (cb != null) p.unregisterCallback(cb) } catch (_: Exception) { }
            try { p.stop() } catch (_: Exception) { }
        }
    }

    override fun onDestroy() {
        stopCapture()
        processor.close()
        executor.shutdownNow()
        super.onDestroy()
    }

    override fun onBind(intent: Intent?) = null

    private fun createChannel() {
        if (Build.VERSION.SDK_INT >= 26) {
            val nm = getSystemService(NotificationManager::class.java)
            nm.createNotificationChannel(
                NotificationChannel(CHANNEL, "Screen analysis", NotificationManager.IMPORTANCE_LOW)
            )
        }
    }
}
