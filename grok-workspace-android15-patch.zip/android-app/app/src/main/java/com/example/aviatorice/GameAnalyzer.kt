package com.example.aviatorice

import java.util.Locale
import kotlin.math.roundToInt

data class RoundRecord(
    val multiplier: Double,
    val timeMillis: Long = System.currentTimeMillis()
)

data class Stats(
    val rounds: Int,
    val lastMultiplier: Double?,
    val roundsSince5x: Int?,
    val roundsSince10x: Int?,
    val average: Double?
)

class GameAnalyzer {
    private val history = ArrayDeque<RoundRecord>()
    private var lastAccepted: Double? = null

    @Synchronized
    fun addMultiplier(value: Double): Boolean {
        if (!value.isFinite() || value < 1.0 || value > 100000.0) return false
        // Debounce repeated OCR frames showing the same multiplier.
        if (lastAccepted != null && kotlin.math.abs(lastAccepted!! - value) < 0.0001) return false
        lastAccepted = value
        history.addLast(RoundRecord(value))
        while (history.size > 500) history.removeFirst()
        return true
    }

    @Synchronized
    fun snapshot(): List<RoundRecord> = history.toList()

    @Synchronized
    fun stats(): Stats {
        val list = history.toList()
        if (list.isEmpty()) return Stats(0, null, null, null, null)
        fun since(threshold: Double): Int? {
            val idx = list.indexOfLast { it.multiplier >= threshold }
            return if (idx < 0) null else list.lastIndex - idx
        }
        return Stats(
            list.size,
            list.last().multiplier,
            since(5.0),
            since(10.0),
            list.map { it.multiplier }.average()
        )
    }

    @Synchronized
    fun csv(): String {
        return buildString {
            appendLine("timestamp,multiplier")
            history.forEach {
                appendLine("${it.timeMillis},${String.format(Locale.US, "%.2f", it.multiplier)}")
            }
        }
    }
}
